import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { discordBot } from "./discord-bot";
import { insertEarningSchema, insertBotActivitySchema, insertIncomeConfigSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Start Discord bot
  discordBot.start();

  // Get dashboard stats
  app.get("/api/dashboard/stats", async (req, res) => {
    try {
      const totalEarnings = await storage.getTotalEarnings();
      const botStats = await storage.getBotStats();
      const recentEarnings = await storage.getEarnings(10);
      const recentActivity = await storage.getBotActivity(10);
      
      // Calculate per-minute rate (last hour)
      const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
      const hourlyEarnings = await storage.getEarningsInTimeRange(oneHourAgo, new Date());
      const perMinuteRate = hourlyEarnings.length > 0 
        ? hourlyEarnings.reduce((sum, e) => sum + parseFloat(e.amount), 0) / 60
        : 0.04;

      // Calculate commands per hour
      const hourlyActivity = await storage.getActivityInTimeRange(oneHourAgo, new Date());
      const commandsPerHour = hourlyActivity.filter(a => a.type === 'command').length;

      res.json({
        totalEarnings: totalEarnings.toFixed(2),
        perMinuteRate: perMinuteRate.toFixed(2),
        activeUsers: botStats?.totalUsers || 0,
        commandsPerHour,
        botStatus: botStats?.isOnline ? 'online' : 'offline',
        uptime: botStats?.uptime || 0,
        recentEarnings,
        recentActivity
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch dashboard stats" });
    }
  });

  // Get earnings chart data
  app.get("/api/earnings/chart", async (req, res) => {
    try {
      const { timeRange = '1h' } = req.query;
      
      let startTime: Date;
      const now = new Date();
      
      switch (timeRange) {
        case '1h':
          startTime = new Date(now.getTime() - 60 * 60 * 1000);
          break;
        case '24h':
          startTime = new Date(now.getTime() - 24 * 60 * 60 * 1000);
          break;
        case '1w':
          startTime = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
          break;
        default:
          startTime = new Date(now.getTime() - 60 * 60 * 1000);
      }

      const earnings = await storage.getEarningsInTimeRange(startTime, now);
      
      // Group earnings by time intervals
      const intervals = timeRange === '1h' ? 12 : timeRange === '24h' ? 24 : 7;
      const intervalMs = (now.getTime() - startTime.getTime()) / intervals;
      
      const chartData = [];
      let cumulativeEarnings = 0;
      
      for (let i = 0; i < intervals; i++) {
        const intervalStart = new Date(startTime.getTime() + i * intervalMs);
        const intervalEnd = new Date(startTime.getTime() + (i + 1) * intervalMs);
        
        const intervalEarnings = earnings.filter(e => 
          e.timestamp >= intervalStart && e.timestamp < intervalEnd
        );
        
        const intervalAmount = intervalEarnings.reduce((sum, e) => sum + parseFloat(e.amount), 0);
        cumulativeEarnings += intervalAmount;
        
        chartData.push({
          time: intervalStart.toISOString(),
          earnings: cumulativeEarnings.toFixed(2),
          intervalAmount: intervalAmount.toFixed(2)
        });
      }
      
      res.json(chartData);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch earnings chart data" });
    }
  });

  // Get activity chart data
  app.get("/api/activity/chart", async (req, res) => {
    try {
      const oneHourAgo = new Date(Date.now() - 60 * 60 * 1000);
      const activity = await storage.getActivityInTimeRange(oneHourAgo, new Date());
      
      // Group by 5-minute intervals
      const intervals = 12;
      const intervalMs = 5 * 60 * 1000; // 5 minutes
      const now = new Date();
      
      const chartData = [];
      
      for (let i = 0; i < intervals; i++) {
        const intervalStart = new Date(now.getTime() - (intervals - i) * intervalMs);
        const intervalEnd = new Date(now.getTime() - (intervals - i - 1) * intervalMs);
        
        const intervalActivity = activity.filter(a => 
          a.timestamp >= intervalStart && a.timestamp < intervalEnd
        );
        
        const commands = intervalActivity.filter(a => a.type === 'command').length;
        const incomeEvents = intervalActivity.filter(a => a.type === 'income_event').length;
        
        chartData.push({
          time: intervalStart.toISOString(),
          commands,
          incomeEvents
        });
      }
      
      res.json(chartData);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch activity chart data" });
    }
  });

  // Get recent earnings for live feed
  app.get("/api/earnings/recent", async (req, res) => {
    try {
      const earnings = await storage.getEarnings(20);
      res.json(earnings);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch recent earnings" });
    }
  });

  // Get command statistics
  app.get("/api/commands/stats", async (req, res) => {
    try {
      const activity = await storage.getBotActivity(1000);
      const commands = activity.filter(a => a.type === 'command');
      
      const commandCounts = commands.reduce((acc, cmd) => {
        const command = cmd.command || 'unknown';
        acc[command] = (acc[command] || 0) + 1;
        return acc;
      }, {} as Record<string, number>);
      
      const sortedCommands = Object.entries(commandCounts)
        .sort(([,a], [,b]) => b - a)
        .slice(0, 10)
        .map(([command, count]) => ({ command, count }));
      
      res.json(sortedCommands);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch command stats" });
    }
  });

  // Get income configuration
  app.get("/api/income/config", async (req, res) => {
    try {
      const config = await storage.getIncomeConfig();
      res.json(config);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch income config" });
    }
  });

  // Update income configuration
  app.put("/api/income/config/:sourceName", async (req, res) => {
    try {
      const { sourceName } = req.params;
      const updates = insertIncomeConfigSchema.partial().parse(req.body);
      
      const updated = await storage.updateIncomeConfig(sourceName, updates);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to update income config" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

import { Bot, DollarSign, BarChart3, Terminal, Settings, History } from "lucide-react";

interface SidebarProps {
  botStatus: string;
  uptime: string;
}

export default function Sidebar({ botStatus, uptime }: SidebarProps) {
  return (
    <div className="hidden md:flex md:flex-col md:w-64 bg-discord-darker">
      <div className="flex-1 flex flex-col min-h-0">
        {/* Logo/Brand */}
        <div className="flex items-center h-16 flex-shrink-0 px-4 bg-discord-darkest">
          <Bot className="text-discord-blurple text-2xl mr-3" />
          <h1 className="text-lg font-semibold">Income Bot</h1>
        </div>
        
        {/* Navigation */}
        <nav className="flex-1 px-2 py-4 space-y-1">
          <a href="#" className="bg-discord-blurple text-white group flex items-center px-2 py-2 text-sm font-medium rounded-md">
            <BarChart3 className="mr-3 h-4 w-4" />
            Dashboard
          </a>
          <a href="#" className="text-discord-light hover:bg-discord-dark hover:text-white group flex items-center px-2 py-2 text-sm font-medium rounded-md">
            <DollarSign className="mr-3 h-4 w-4" />
            Earnings
          </a>
          <a href="#" className="text-discord-light hover:bg-discord-dark hover:text-white group flex items-center px-2 py-2 text-sm font-medium rounded-md">
            <Terminal className="mr-3 h-4 w-4" />
            Commands
          </a>
          <a href="#" className="text-discord-light hover:bg-discord-dark hover:text-white group flex items-center px-2 py-2 text-sm font-medium rounded-md">
            <Settings className="mr-3 h-4 w-4" />
            Settings
          </a>
          <a href="#" className="text-discord-light hover:bg-discord-dark hover:text-white group flex items-center px-2 py-2 text-sm font-medium rounded-md">
            <History className="mr-3 h-4 w-4" />
            Logs
          </a>
        </nav>

        {/* Bot Status */}
        <div className="flex-shrink-0 p-4">
          <div className="bg-discord-dark rounded-lg p-3">
            <div className="flex items-center">
              <div className={`w-3 h-3 rounded-full ${botStatus === 'online' ? 'bg-discord-green animate-pulse' : 'bg-gray-500'}`}></div>
              <span className="ml-2 text-sm font-medium">
                Bot {botStatus === 'online' ? 'Online' : 'Offline'}
              </span>
            </div>
            <p className="text-xs text-discord-light mt-1">
              Uptime: {uptime}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

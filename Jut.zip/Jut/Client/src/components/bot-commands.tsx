import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Terminal } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export default function BotCommands() {
  const [commandInput, setCommandInput] = useState('');
  const { toast } = useToast();
  
  const { data: commandStats, isLoading } = useQuery({
    queryKey: ['/api/commands/stats'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const handleExecuteCommand = () => {
    if (!commandInput.trim()) {
      toast({
        title: "Error",
        description: "Please enter a command",
        variant: "destructive",
      });
      return;
    }

    // Simulate command execution
    toast({
      title: "Command Executed",
      description: `Command "${commandInput}" would be sent to Discord bot`,
    });
    
    setCommandInput('');
  };

  const defaultCommands = [
    { command: 'earnings', count: 1247 },
    { command: 'tip', count: 856 },
    { command: 'stats', count: 643 },
    { command: 'leaderboard', count: 432 },
    { command: 'help', count: 321 },
  ];

  const commands = commandStats && commandStats.length > 0 ? commandStats : defaultCommands;

  const getCommandDescription = (command: string) => {
    const descriptions: Record<string, string> = {
      earnings: 'Check total earnings',
      tip: 'Send tip to bot',
      stats: 'View bot statistics',
      leaderboard: 'Top contributors',
      help: 'Show available commands',
    };
    return descriptions[command] || 'Bot command';
  };

  return (
    <Card className="bg-discord-darker border-discord-dark">
      <CardHeader className="border-b border-discord-dark">
        <CardTitle className="flex items-center">
          <Terminal className="text-discord-blurple mr-2 h-5 w-5" />
          Popular Commands
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-4">
          {isLoading ? (
            [...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center justify-between">
                <div className="flex items-center">
                  <Skeleton className="h-6 w-20 mr-3 bg-discord-dark" />
                  <Skeleton className="h-4 w-32 bg-discord-dark" />
                </div>
                <Skeleton className="h-4 w-16 bg-discord-dark" />
              </div>
            ))
          ) : (
            commands.map((cmd, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center">
                  <code className="bg-discord-dark px-2 py-1 rounded text-sm font-mono">
                    !{cmd.command}
                  </code>
                  <span className="ml-3 text-sm text-discord-light">
                    {getCommandDescription(cmd.command)}
                  </span>
                </div>
                <span className="text-sm font-medium">{cmd.count} uses</span>
              </div>
            ))
          )}
        </div>

        {/* Command Tester */}
        <div className="mt-6 pt-4 border-t border-discord-dark">
          <h4 className="text-sm font-medium mb-3">Test Commands</h4>
          <div className="flex space-x-2">
            <Input
              type="text"
              placeholder="Enter command..."
              value={commandInput}
              onChange={(e) => setCommandInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleExecuteCommand()}
              className="flex-1 bg-discord-dark border-discord-dark text-white placeholder:text-discord-light"
            />
            <Button 
              onClick={handleExecuteCommand}
              className="bg-discord-blurple hover:bg-discord-dark-blurple"
            >
              Execute
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

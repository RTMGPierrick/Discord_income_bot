import { DollarSign, Clock, Users, Command } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface StatsProps {
  stats?: {
    totalEarnings: string;
    perMinuteRate: string;
    activeUsers: number;
    commandsPerHour: number;
  };
  isLoading: boolean;
}

export default function StatsOverview({ stats, isLoading }: StatsProps) {
  if (isLoading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="bg-discord-darker border-discord-dark">
            <CardContent className="p-6">
              <Skeleton className="h-8 w-8 mb-4 bg-discord-dark" />
              <Skeleton className="h-4 w-24 mb-2 bg-discord-dark" />
              <Skeleton className="h-8 w-16 mb-2 bg-discord-dark" />
              <Skeleton className="h-3 w-32 bg-discord-dark" />
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const statCards = [
    {
      title: "Total Earnings",
      value: `$${stats?.totalEarnings || '0.00'}`,
      icon: DollarSign,
      iconColor: "text-discord-green",
      change: "+12.5% from yesterday"
    },
    {
      title: "Per Minute",
      value: `$${stats?.perMinuteRate || '0.00'}`,
      icon: Clock,
      iconColor: "text-discord-blurple",
      change: "Live rate"
    },
    {
      title: "Active Users",
      value: stats?.activeUsers?.toLocaleString() || '0',
      icon: Users,
      iconColor: "text-discord-yellow",
      change: "+23 new today"
    },
    {
      title: "Commands/Hour",
      value: stats?.commandsPerHour?.toString() || '0',
      icon: Command,
      iconColor: "text-discord-red",
      change: "Average response: 120ms"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {statCards.map((stat, index) => (
        <Card key={index} className="bg-discord-darker border-discord-dark">
          <CardContent className="p-6">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <stat.icon className={`h-8 w-8 ${stat.iconColor}`} />
              </div>
              <div className="ml-4">
                <p className="text-sm font-medium text-discord-light">{stat.title}</p>
                <p className="text-2xl font-semibold">{stat.value}</p>
              </div>
            </div>
            <div className="mt-2">
              <span className="text-xs text-discord-green">{stat.change}</span>
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}

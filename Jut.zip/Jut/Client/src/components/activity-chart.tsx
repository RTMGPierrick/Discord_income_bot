import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Bar } from "react-chartjs-2";
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export default function ActivityChart() {
  const { data: activityData, isLoading } = useQuery({
    queryKey: ['/api/activity/chart'],
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        display: false,
      },
    },
    scales: {
      x: {
        grid: {
          color: '#4F5258',
        },
        ticks: {
          color: '#B9BBBE',
          callback: function(value: any, index: number) {
            const date = new Date(activityData?.[index]?.time || '');
            return date.toLocaleTimeString('en-US', { 
              hour: '2-digit', 
              minute: '2-digit' 
            });
          }
        },
      },
      y: {
        grid: {
          color: '#4F5258',
        },
        ticks: {
          color: '#B9BBBE',
        },
      },
    },
  };

  const chartDataFormatted = {
    labels: activityData?.map((_, index) => index) || [],
    datasets: [
      {
        label: 'Commands',
        data: activityData?.map(item => item.commands) || [],
        backgroundColor: 'rgba(0, 209, 102, 0.8)',
        borderRadius: 4,
      },
      {
        label: 'Income Events',
        data: activityData?.map(item => item.incomeEvents) || [],
        backgroundColor: 'rgba(88, 101, 242, 0.8)',
        borderRadius: 4,
      },
    ],
  };

  return (
    <Card className="bg-discord-darker border-discord-dark">
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg font-semibold">Bot Activity</CardTitle>
          <div className="flex space-x-2">
            <Badge variant="secondary" className="bg-discord-green/20 text-discord-green hover:bg-discord-green/30">
              <div className="w-2 h-2 bg-discord-green rounded-full mr-1"></div>
              Commands
            </Badge>
            <Badge variant="secondary" className="bg-discord-blurple/20 text-discord-blurple hover:bg-discord-blurple/30">
              <div className="w-2 h-2 bg-discord-blurple rounded-full mr-1"></div>
              Income Events
            </Badge>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          {isLoading ? (
            <Skeleton className="w-full h-full bg-discord-dark" />
          ) : (
            <Bar data={chartDataFormatted} options={chartOptions} />
          )}
        </div>
      </CardContent>
    </Card>
  );
}

import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Radio } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function LiveIncomeFeed() {
  const { data: earnings, isLoading } = useQuery({
    queryKey: ['/api/earnings/recent'],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const getEventIcon = (source: string) => {
    switch (source) {
      case 'tip':
        return 'bg-discord-green';
      case 'command':
        return 'bg-discord-blurple';
      case 'auto':
        return 'bg-discord-yellow';
      default:
        return 'bg-discord-light';
    }
  };

  const getEventType = (source: string, description: string) => {
    switch (source) {
      case 'tip':
        return 'Tip received';
      case 'command':
        return 'Command executed';
      case 'auto':
        return 'Automated earning';
      default:
        return 'Income event';
    }
  };

  const getEventDescription = (earning: any) => {
    if (earning.source === 'tip' && earning.userId) {
      return `from user ${earning.userId.slice(-4)}`;
    }
    if (earning.source === 'command') {
      return earning.description;
    }
    if (earning.source === 'auto') {
      return 'Minute milestone';
    }
    return earning.description;
  };

  return (
    <Card className="bg-discord-darker border-discord-dark">
      <CardHeader className="border-b border-discord-dark">
        <CardTitle className="flex items-center">
          <Radio className="text-discord-green mr-2 h-5 w-5" />
          Live Income Feed
        </CardTitle>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-3 max-h-80 overflow-y-auto">
          {isLoading ? (
            [...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center justify-between p-3 bg-discord-dark rounded-lg">
                <div className="flex items-center">
                  <Skeleton className="w-2 h-2 rounded-full mr-3 bg-discord-light" />
                  <div>
                    <Skeleton className="h-4 w-24 mb-1 bg-discord-light" />
                    <Skeleton className="h-3 w-32 bg-discord-light" />
                  </div>
                </div>
                <div className="text-right">
                  <Skeleton className="h-4 w-16 mb-1 bg-discord-light" />
                  <Skeleton className="h-3 w-12 bg-discord-light" />
                </div>
              </div>
            ))
          ) : earnings && earnings.length > 0 ? (
            earnings.map((earning: any) => (
              <div key={earning.id} className="flex items-center justify-between p-3 bg-discord-dark rounded-lg">
                <div className="flex items-center">
                  <div className={`w-2 h-2 rounded-full mr-3 animate-pulse ${getEventIcon(earning.source)}`}></div>
                  <div>
                    <p className="text-sm font-medium">{getEventType(earning.source, earning.description)}</p>
                    <p className="text-xs text-discord-light">{getEventDescription(earning)}</p>
                  </div>
                </div>
                <div className="text-right">
                  <p className={`text-sm font-semibold text-discord-green`}>
                    +${parseFloat(earning.amount).toFixed(2)}
                  </p>
                  <p className="text-xs text-discord-light">
                    {formatDistanceToNow(new Date(earning.timestamp), { addSuffix: true })}
                  </p>
                </div>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-discord-light">
              <p>No income events yet</p>
              <p className="text-xs mt-1">Income will appear here as it's generated</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

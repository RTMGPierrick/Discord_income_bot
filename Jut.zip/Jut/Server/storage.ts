import { 
  earnings, 
  botActivity, 
  botStats, 
  incomeConfig,
  type Earning, 
  type InsertEarning,
  type BotActivity,
  type InsertBotActivity,
  type BotStats,
  type InsertBotStats,
  type IncomeConfig,
  type InsertIncomeConfig
} from "@shared/schema";

export interface IStorage {
  // Earnings
  createEarning(earning: InsertEarning): Promise<Earning>;
  getEarnings(limit?: number): Promise<Earning[]>;
  getTotalEarnings(): Promise<number>;
  getEarningsInTimeRange(startTime: Date, endTime: Date): Promise<Earning[]>;
  
  // Bot Activity
  createBotActivity(activity: InsertBotActivity): Promise<BotActivity>;
  getBotActivity(limit?: number): Promise<BotActivity[]>;
  getActivityInTimeRange(startTime: Date, endTime: Date): Promise<BotActivity[]>;
  
  // Bot Stats
  updateBotStats(stats: Partial<InsertBotStats>): Promise<BotStats>;
  getBotStats(): Promise<BotStats | undefined>;
  
  // Income Config
  getIncomeConfig(): Promise<IncomeConfig[]>;
  updateIncomeConfig(sourceName: string, config: Partial<InsertIncomeConfig>): Promise<IncomeConfig>;
}

export class MemStorage implements IStorage {
  private earnings: Map<number, Earning>;
  private botActivities: Map<number, BotActivity>;
  private botStatsData: BotStats | undefined;
  private incomeConfigs: Map<string, IncomeConfig>;
  private currentEarningId: number;
  private currentActivityId: number;
  private currentConfigId: number;

  constructor() {
    this.earnings = new Map();
    this.botActivities = new Map();
    this.incomeConfigs = new Map();
    this.currentEarningId = 1;
    this.currentActivityId = 1;
    this.currentConfigId = 1;
    
    // Initialize default income config
    this.initializeIncomeConfig();
    this.initializeBotStats();
  }

  private initializeIncomeConfig() {
    const configs = [
      { sourceName: 'tips', enabled: true, minRate: '0.05', maxRate: '2.00' },
      { sourceName: 'commands', enabled: true, minRate: '0.01', maxRate: '0.05' },
      { sourceName: 'auto', enabled: true, minRate: '0.04', maxRate: '0.04' }
    ];
    
    configs.forEach(config => {
      const incomeConfig: IncomeConfig = {
        id: this.currentConfigId++,
        ...config
      };
      this.incomeConfigs.set(config.sourceName, incomeConfig);
    });
  }

  private initializeBotStats() {
    this.botStatsData = {
      id: 1,
      isOnline: true,
      uptime: 0,
      totalUsers: 1247,
      totalGuilds: 5,
      lastUpdate: new Date()
    };
  }

  async createEarning(insertEarning: InsertEarning): Promise<Earning> {
    const id = this.currentEarningId++;
    const earning: Earning = { 
      ...insertEarning, 
      id, 
      timestamp: new Date() 
    };
    this.earnings.set(id, earning);
    return earning;
  }

  async getEarnings(limit = 50): Promise<Earning[]> {
    const allEarnings = Array.from(this.earnings.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    return allEarnings.slice(0, limit);
  }

  async getTotalEarnings(): Promise<number> {
    return Array.from(this.earnings.values())
      .reduce((total, earning) => total + parseFloat(earning.amount), 0);
  }

  async getEarningsInTimeRange(startTime: Date, endTime: Date): Promise<Earning[]> {
    return Array.from(this.earnings.values())
      .filter(earning => earning.timestamp >= startTime && earning.timestamp <= endTime)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  async createBotActivity(insertActivity: InsertBotActivity): Promise<BotActivity> {
    const id = this.currentActivityId++;
    const activity: BotActivity = { 
      ...insertActivity, 
      id, 
      timestamp: new Date() 
    };
    this.botActivities.set(id, activity);
    return activity;
  }

  async getBotActivity(limit = 50): Promise<BotActivity[]> {
    const allActivities = Array.from(this.botActivities.values())
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    return allActivities.slice(0, limit);
  }

  async getActivityInTimeRange(startTime: Date, endTime: Date): Promise<BotActivity[]> {
    return Array.from(this.botActivities.values())
      .filter(activity => activity.timestamp >= startTime && activity.timestamp <= endTime)
      .sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
  }

  async updateBotStats(stats: Partial<InsertBotStats>): Promise<BotStats> {
    this.botStatsData = {
      ...this.botStatsData!,
      ...stats,
      lastUpdate: new Date()
    };
    return this.botStatsData;
  }

  async getBotStats(): Promise<BotStats | undefined> {
    return this.botStatsData;
  }

  async getIncomeConfig(): Promise<IncomeConfig[]> {
    return Array.from(this.incomeConfigs.values());
  }

  async updateIncomeConfig(sourceName: string, config: Partial<InsertIncomeConfig>): Promise<IncomeConfig> {
    const existing = this.incomeConfigs.get(sourceName);
    if (!existing) {
      throw new Error(`Income config for ${sourceName} not found`);
    }
    
    const updated: IncomeConfig = { ...existing, ...config };
    this.incomeConfigs.set(sourceName, updated);
    return updated;
  }
}

export const storage = new MemStorage();

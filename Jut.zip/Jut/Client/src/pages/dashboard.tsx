import { useQuery } from "@tanstack/react-query";
import Sidebar from "@/components/sidebar";
import StatsOverview from "@/components/stats-overview";
import EarningsChart from "@/components/earnings-chart";
import ActivityChart from "@/components/activity-chart";
import LiveIncomeFeed from "@/components/live-income-feed";
import BotCommands from "@/components/bot-commands";
import IncomeSources from "@/components/income-sources";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";
import { queryClient } from "@/lib/queryClient";

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['/api/dashboard/stats'],
    refetchInterval: 5000, // Refresh every 5 seconds
  });

  const handleRefresh = () => {
    queryClient.invalidateQueries();
  };

  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    return `${hours}h ${minutes}m`;
  };

  return (
    <div className="flex h-screen overflow-hidden bg-discord-darkest text-white">
      <Sidebar 
        botStatus={stats?.botStatus || 'offline'} 
        uptime={stats ? formatUptime(stats.uptime) : '0h 0m'} 
      />
      
      <div className="flex-1 overflow-auto">
        {/* Header */}
        <header className="bg-discord-darker shadow-sm border-b border-discord-dark">
          <div className="px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between items-center py-4">
              <div className="flex items-center">
                <h1 className="text-2xl font-semibold">Dashboard</h1>
              </div>
              <div className="flex items-center space-x-4">
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-discord-light">Last Update:</span>
                  <span className="text-sm font-medium">
                    {isLoading ? 'Loading...' : 'Just now'}
                  </span>
                </div>
                <Button 
                  onClick={handleRefresh}
                  className="bg-discord-blurple hover:bg-discord-dark-blurple"
                  size="sm"
                >
                  <RefreshCw className="mr-2 h-4 w-4" />
                  Refresh
                </Button>
              </div>
            </div>
          </div>
        </header>

        {/* Dashboard Content */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8">
          <StatsOverview stats={stats} isLoading={isLoading} />
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <EarningsChart />
            <ActivityChart />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
            <LiveIncomeFeed />
            <BotCommands />
          </div>

          <IncomeSources />
        </main>
      </div>
    </div>
  );
}

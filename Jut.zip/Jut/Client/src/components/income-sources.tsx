import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Skeleton } from "@/components/ui/skeleton";
import { PiggyBank } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function IncomeSources() {
  const { toast } = useToast();
  
  const { data: incomeConfig, isLoading } = useQuery({
    queryKey: ['/api/income/config'],
  });

  const updateConfigMutation = useMutation({
    mutationFn: async ({ sourceName, enabled }: { sourceName: string; enabled: boolean }) => {
      return await apiRequest('PUT', `/api/income/config/${sourceName}`, { enabled });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/income/config'] });
      toast({
        title: "Configuration Updated",
        description: "Income source settings have been saved",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to update configuration",
        variant: "destructive",
      });
    }
  });

  const handleToggle = (sourceName: string, enabled: boolean) => {
    updateConfigMutation.mutate({ sourceName, enabled });
  };

  const getSourceDescription = (sourceName: string, config: any) => {
    switch (sourceName) {
      case 'tips':
        return {
          title: 'User Tips',
          description: `Rate: $${config.minRate}-$${config.maxRate} per tip`,
          stats: '24 tips today (+$12.40)'
        };
      case 'commands':
        return {
          title: 'Command Usage',
          description: `Rate: $${config.minRate}-$${config.maxRate} per command`,
          stats: '438 commands today (+$8.76)'
        };
      case 'auto':
        return {
          title: 'Auto Income',
          description: `Rate: $${config.minRate} per minute`,
          stats: '154 minutes today (+$6.16)'
        };
      default:
        return {
          title: sourceName,
          description: 'Custom income source',
          stats: 'No data available'
        };
    }
  };

  return (
    <Card className="bg-discord-darker border-discord-dark">
      <CardHeader className="border-b border-discord-dark">
        <CardTitle className="flex items-center">
          <PiggyBank className="text-discord-yellow mr-2 h-5 w-5" />
          Income Sources Configuration
        </CardTitle>
        <p className="text-sm text-discord-light mt-1">
          Configure and monitor different revenue streams
        </p>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {isLoading ? (
            [...Array(3)].map((_, i) => (
              <div key={i} className="bg-discord-dark rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <Skeleton className="h-5 w-24 bg-discord-light" />
                  <Skeleton className="h-6 w-11 bg-discord-light" />
                </div>
                <Skeleton className="h-4 w-32 mb-2 bg-discord-light" />
                <Skeleton className="h-3 w-28 bg-discord-light" />
              </div>
            ))
          ) : incomeConfig ? (
            incomeConfig.map((config: any) => {
              const sourceInfo = getSourceDescription(config.sourceName, config);
              
              return (
                <div key={config.id} className="bg-discord-dark rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium">{sourceInfo.title}</h4>
                    <Switch
                      checked={config.enabled}
                      onCheckedChange={(enabled) => handleToggle(config.sourceName, enabled)}
                      disabled={updateConfigMutation.isPending}
                    />
                  </div>
                  <p className="text-sm text-discord-light mb-2">
                    {sourceInfo.description}
                  </p>
                  <p className="text-xs text-discord-green">
                    {sourceInfo.stats}
                  </p>
                </div>
              );
            })
          ) : (
            <div className="col-span-3 text-center py-8 text-discord-light">
              <p>No income sources configured</p>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

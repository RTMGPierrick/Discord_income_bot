import { Client, GatewayIntentBits, Events, SlashCommandBuilder, REST, Routes } from 'discord.js';
import { storage } from './storage';

class DiscordIncomeBot {
  private client: Client;
  private incomeInterval: NodeJS.Timeout | null = null;
  private startTime: Date;

  constructor() {
    this.client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
      ],
    });
    this.startTime = new Date();
    this.setupEventHandlers();
  }

  private setupEventHandlers() {
    this.client.once(Events.ClientReady, () => {
      console.log(`Discord bot logged in as ${this.client.user?.tag}!`);
      this.startIncomeGeneration();
      this.updateBotStats();
      this.registerCommands();
    });

    this.client.on(Events.InteractionCreate, async (interaction) => {
      if (!interaction.isChatInputCommand()) return;

      await this.handleCommand(interaction);
    });

    this.client.on(Events.GuildCreate, (guild) => {
      this.updateBotStats();
    });

    this.client.on(Events.GuildDelete, (guild) => {
      this.updateBotStats();
    });
  }

  private async registerCommands() {
    const commands = [
      new SlashCommandBuilder()
        .setName('earnings')
        .setDescription('Check total bot earnings'),
      
      new SlashCommandBuilder()
        .setName('tip')
        .setDescription('Send a tip to the bot')
        .addNumberOption(option =>
          option.setName('amount')
            .setDescription('Tip amount in dollars')
            .setRequired(true)
            .setMinValue(0.01)
            .setMaxValue(100)
        ),
      
      new SlashCommandBuilder()
        .setName('stats')
        .setDescription('View bot statistics'),
      
      new SlashCommandBuilder()
        .setName('leaderboard')
        .setDescription('View top contributors'),
      
      new SlashCommandBuilder()
        .setName('help')
        .setDescription('Show available commands'),
    ];

    const rest = new REST().setToken(process.env.DISCORD_BOT_TOKEN!);

    try {
      console.log('Started refreshing application (/) commands.');
      await rest.put(
        Routes.applicationCommands(process.env.DISCORD_CLIENT_ID!),
        { body: commands },
      );
      console.log('Successfully reloaded application (/) commands.');
    } catch (error) {
      console.error(error);
    }
  }

  private async handleCommand(interaction: any) {
    const { commandName, user } = interaction;

    // Log the command activity
    await storage.createBotActivity({
      type: 'command',
      command: commandName,
      userId: user.id,
      guildId: interaction.guildId,
    });

    // Generate command-based income
    const config = await storage.getIncomeConfig();
    const commandConfig = config.find(c => c.sourceName === 'commands' && c.enabled);
    
    if (commandConfig) {
      const amount = this.generateRandomAmount(
        parseFloat(commandConfig.minRate),
        parseFloat(commandConfig.maxRate)
      );
      
      await storage.createEarning({
        amount: amount.toFixed(2),
        source: 'command',
        userId: user.id,
        description: `Command: /${commandName}`,
      });
    }

    switch (commandName) {
      case 'earnings':
        const totalEarnings = await storage.getTotalEarnings();
        await interaction.reply(`💰 Total bot earnings: $${totalEarnings.toFixed(2)}`);
        break;

      case 'tip':
        const tipAmount = interaction.options.getNumber('amount');
        await storage.createEarning({
          amount: tipAmount.toFixed(2),
          source: 'tip',
          userId: user.id,
          description: `Tip from ${user.username}`,
        });
        await interaction.reply(`🙏 Thank you for the $${tipAmount.toFixed(2)} tip!`);
        break;

      case 'stats':
        const stats = await storage.getBotStats();
        const uptime = stats ? Math.floor((Date.now() - this.startTime.getTime()) / 1000) : 0;
        const hours = Math.floor(uptime / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        
        await interaction.reply(
          `📊 **Bot Statistics**\n` +
          `🟢 Status: Online\n` +
          `⏰ Uptime: ${hours}h ${minutes}m\n` +
          `👥 Servers: ${this.client.guilds.cache.size}\n` +
          `💰 Total Earnings: $${(await storage.getTotalEarnings()).toFixed(2)}`
        );
        break;

      case 'leaderboard':
        const recentEarnings = await storage.getEarnings(10);
        const userTotals = new Map();
        
        recentEarnings.forEach(earning => {
          if (earning.userId) {
            const current = userTotals.get(earning.userId) || 0;
            userTotals.set(earning.userId, current + parseFloat(earning.amount));
          }
        });

        const sorted = Array.from(userTotals.entries())
          .sort(([,a], [,b]) => b - a)
          .slice(0, 5);

        const leaderboard = sorted.length > 0 
          ? sorted.map(([userId, total], index) => 
              `${index + 1}. <@${userId}>: $${total.toFixed(2)}`
            ).join('\n')
          : 'No contributions yet!';

        await interaction.reply(`🏆 **Top Contributors**\n${leaderboard}`);
        break;

      case 'help':
        await interaction.reply(
          `🤖 **Available Commands**\n` +
          `\`/earnings\` - Check total bot earnings\n` +
          `\`/tip <amount>\` - Send a tip to the bot\n` +
          `\`/stats\` - View bot statistics\n` +
          `\`/leaderboard\` - View top contributors\n` +
          `\`/help\` - Show this help message`
        );
        break;

      default:
        await interaction.reply('Unknown command!');
    }
  }

  private startIncomeGeneration() {
    // Generate income every minute
    this.incomeInterval = setInterval(async () => {
      const config = await storage.getIncomeConfig();
      const autoConfig = config.find(c => c.sourceName === 'auto' && c.enabled);
      
      if (autoConfig) {
        const amount = parseFloat(autoConfig.minRate);
        
        await storage.createEarning({
          amount: amount.toFixed(2),
          source: 'auto',
          userId: null,
          description: 'Automated minute earning',
        });

        await storage.createBotActivity({
          type: 'income_event',
          command: null,
          userId: null,
          guildId: null,
        });
      }
    }, 60000); // Every minute
  }

  private async updateBotStats() {
    const uptime = Math.floor((Date.now() - this.startTime.getTime()) / 1000);
    
    await storage.updateBotStats({
      isOnline: true,
      uptime,
      totalUsers: this.client.users.cache.size,
      totalGuilds: this.client.guilds.cache.size,
    });
  }

  private generateRandomAmount(min: number, max: number): number {
    return Math.random() * (max - min) + min;
  }

  public async start() {
    const token = process.env.DISCORD_BOT_TOKEN;
    if (!token) {
      console.error('DISCORD_BOT_TOKEN environment variable is required');
      return;
    }

    try {
      await this.client.login(token);
    } catch (error) {
      console.error('Failed to start Discord bot:', error);
    }
  }

  public stop() {
    if (this.incomeInterval) {
      clearInterval(this.incomeInterval);
    }
    this.client.destroy();
  }
}

export const discordBot = new DiscordIncomeBot();
